How to run in Visual Studio 2022

1. Unzip the archive.
2. Open TTSLab4WinForms.sln in Visual Studio 2022.
3. If Visual Studio asks to trust or restore anything, accept.
4. Press F5.

What the app does

- Enter text
- Choose a voice installed in Windows
- Adjust speaking rate and volume
- Press Speak to play speech
- Press Stop to cancel playback
- Press Save WAV to export speech to a .wav file

Notes

- The project uses System.Speech, so it depends on voices installed in Windows.
- If only one voice is available on your PC, only that voice will appear.
