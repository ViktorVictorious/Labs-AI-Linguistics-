namespace TTSLab4WinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox textInput;
        private System.Windows.Forms.Button buttonSpeak;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonSaveWav;
        private System.Windows.Forms.ComboBox comboVoices;
        private System.Windows.Forms.Label labelVoice;
        private System.Windows.Forms.Label labelRate;
        private System.Windows.Forms.Label labelVolume;
        private System.Windows.Forms.TrackBar trackRate;
        private System.Windows.Forms.TrackBar trackVolume;
        private System.Windows.Forms.Label labelRateValue;
        private System.Windows.Forms.Label labelVolumeValue;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.textInput = new System.Windows.Forms.TextBox();
            this.buttonSpeak = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.buttonSaveWav = new System.Windows.Forms.Button();
            this.comboVoices = new System.Windows.Forms.ComboBox();
            this.labelVoice = new System.Windows.Forms.Label();
            this.labelRate = new System.Windows.Forms.Label();
            this.labelVolume = new System.Windows.Forms.Label();
            this.trackRate = new System.Windows.Forms.TrackBar();
            this.trackVolume = new System.Windows.Forms.TrackBar();
            this.labelRateValue = new System.Windows.Forms.Label();
            this.labelVolumeValue = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.trackRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackVolume)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textInput
            // 
            this.textInput.Location = new System.Drawing.Point(12, 12);
            this.textInput.Multiline = true;
            this.textInput.Name = "textInput";
            this.textInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textInput.Size = new System.Drawing.Size(560, 180);
            this.textInput.TabIndex = 0;
            this.textInput.Text = "Hello. This is a simple text to speech application.";
            // 
            // buttonSpeak
            // 
            this.buttonSpeak.Location = new System.Drawing.Point(12, 289);
            this.buttonSpeak.Name = "buttonSpeak";
            this.buttonSpeak.Size = new System.Drawing.Size(100, 32);
            this.buttonSpeak.TabIndex = 1;
            this.buttonSpeak.Text = "Speak";
            this.buttonSpeak.UseVisualStyleBackColor = true;
            this.buttonSpeak.Click += new System.EventHandler(this.buttonSpeak_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(118, 289);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(100, 32);
            this.buttonStop.TabIndex = 2;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // buttonSaveWav
            // 
            this.buttonSaveWav.Location = new System.Drawing.Point(224, 289);
            this.buttonSaveWav.Name = "buttonSaveWav";
            this.buttonSaveWav.Size = new System.Drawing.Size(120, 32);
            this.buttonSaveWav.TabIndex = 3;
            this.buttonSaveWav.Text = "Save WAV";
            this.buttonSaveWav.UseVisualStyleBackColor = true;
            this.buttonSaveWav.Click += new System.EventHandler(this.buttonSaveWav_Click);
            // 
            // comboVoices
            // 
            this.comboVoices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboVoices.FormattingEnabled = true;
            this.comboVoices.Location = new System.Drawing.Point(67, 208);
            this.comboVoices.Name = "comboVoices";
            this.comboVoices.Size = new System.Drawing.Size(277, 24);
            this.comboVoices.TabIndex = 4;
            // 
            // labelVoice
            // 
            this.labelVoice.AutoSize = true;
            this.labelVoice.Location = new System.Drawing.Point(12, 211);
            this.labelVoice.Name = "labelVoice";
            this.labelVoice.Size = new System.Drawing.Size(42, 16);
            this.labelVoice.TabIndex = 5;
            this.labelVoice.Text = "Voice";
            // 
            // labelRate
            // 
            this.labelRate.AutoSize = true;
            this.labelRate.Location = new System.Drawing.Point(12, 245);
            this.labelRate.Name = "labelRate";
            this.labelRate.Size = new System.Drawing.Size(36, 16);
            this.labelRate.TabIndex = 6;
            this.labelRate.Text = "Rate";
            // 
            // labelVolume
            // 
            this.labelVolume.AutoSize = true;
            this.labelVolume.Location = new System.Drawing.Point(296, 245);
            this.labelVolume.Name = "labelVolume";
            this.labelVolume.Size = new System.Drawing.Size(52, 16);
            this.labelVolume.TabIndex = 7;
            this.labelVolume.Text = "Volume";
            // 
            // trackRate
            // 
            this.trackRate.Location = new System.Drawing.Point(54, 238);
            this.trackRate.Maximum = 10;
            this.trackRate.Minimum = -10;
            this.trackRate.Name = "trackRate";
            this.trackRate.Size = new System.Drawing.Size(177, 56);
            this.trackRate.TabIndex = 8;
            this.trackRate.TickFrequency = 1;
            this.trackRate.Scroll += new System.EventHandler(this.trackRate_Scroll);
            // 
            // trackVolume
            // 
            this.trackVolume.Location = new System.Drawing.Point(354, 238);
            this.trackVolume.Maximum = 100;
            this.trackVolume.Name = "trackVolume";
            this.trackVolume.Size = new System.Drawing.Size(177, 56);
            this.trackVolume.TabIndex = 9;
            this.trackVolume.TickFrequency = 10;
            this.trackVolume.Value = 100;
            this.trackVolume.Scroll += new System.EventHandler(this.trackVolume_Scroll);
            // 
            // labelRateValue
            // 
            this.labelRateValue.AutoSize = true;
            this.labelRateValue.Location = new System.Drawing.Point(237, 245);
            this.labelRateValue.Name = "labelRateValue";
            this.labelRateValue.Size = new System.Drawing.Size(14, 16);
            this.labelRateValue.TabIndex = 10;
            this.labelRateValue.Text = "0";
            // 
            // labelVolumeValue
            // 
            this.labelVolumeValue.AutoSize = true;
            this.labelVolumeValue.Location = new System.Drawing.Point(537, 245);
            this.labelVolumeValue.Name = "labelVolumeValue";
            this.labelVolumeValue.Size = new System.Drawing.Size(28, 16);
            this.labelVolumeValue.TabIndex = 11;
            this.labelVolumeValue.Text = "100";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 331);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(584, 26);
            this.statusStrip1.TabIndex = 12;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusLabel
            // 
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(42, 20);
            this.statusLabel.Text = "Ready";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 357);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.labelVolumeValue);
            this.Controls.Add(this.labelRateValue);
            this.Controls.Add(this.trackVolume);
            this.Controls.Add(this.trackRate);
            this.Controls.Add(this.labelVolume);
            this.Controls.Add(this.labelRate);
            this.Controls.Add(this.labelVoice);
            this.Controls.Add(this.comboVoices);
            this.Controls.Add(this.buttonSaveWav);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonSpeak);
            this.Controls.Add(this.textInput);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab 4 - Text to Speech";
            ((System.ComponentModel.ISupportInitialize)(this.trackRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackVolume)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
