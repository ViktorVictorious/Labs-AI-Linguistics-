using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TTSLab4WinForms")]
[assembly: AssemblyDescription("Lab 4 text to speech app")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TTSLab4WinForms")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("5b2fe5c7-29dd-451d-97ad-1d6b1f4d54d8")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
