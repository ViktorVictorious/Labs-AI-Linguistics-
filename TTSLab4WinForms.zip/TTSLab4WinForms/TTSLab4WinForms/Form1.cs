using System;
using System.IO;
using System.Speech.Synthesis;
using System.Windows.Forms;

namespace TTSLab4WinForms
{
    public partial class Form1 : Form
    {
        private readonly SpeechSynthesizer _synthesizer;

        public Form1()
        {
            InitializeComponent();
            _synthesizer = new SpeechSynthesizer();
            LoadVoices();
            _synthesizer.SpeakStarted += Synthesizer_SpeakStarted;
            _synthesizer.SpeakCompleted += Synthesizer_SpeakCompleted;
            _synthesizer.SetOutputToDefaultAudioDevice();
        }

        private void LoadVoices()
        {
            comboVoices.Items.Clear();

            foreach (InstalledVoice voice in _synthesizer.GetInstalledVoices())
            {
                comboVoices.Items.Add(voice.VoiceInfo.Name);
            }

            if (comboVoices.Items.Count > 0)
            {
                comboVoices.SelectedIndex = 0;
            }
        }

        private void buttonSpeak_Click(object sender, EventArgs e)
        {
            string text = textInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                MessageBox.Show("Enter text first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                if (comboVoices.SelectedItem != null)
                {
                    _synthesizer.SelectVoice(comboVoices.SelectedItem.ToString());
                }

                _synthesizer.Rate = trackRate.Value;
                _synthesizer.Volume = trackVolume.Value;
                _synthesizer.SetOutputToDefaultAudioDevice();
                _synthesizer.SpeakAsyncCancelAll();
                _synthesizer.SpeakAsync(text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            _synthesizer.SpeakAsyncCancelAll();
            statusLabel.Text = "Stopped";
        }

        private void buttonSaveWav_Click(object sender, EventArgs e)
        {
            string text = textInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                MessageBox.Show("Enter text first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "WAV files (*.wav)|*.wav";
                dialog.FileName = "speech.wav";

                if (dialog.ShowDialog() != DialogResult.OK)
                {
                    return;
                }

                try
                {
                    if (comboVoices.SelectedItem != null)
                    {
                        _synthesizer.SelectVoice(comboVoices.SelectedItem.ToString());
                    }

                    _synthesizer.Rate = trackRate.Value;
                    _synthesizer.Volume = trackVolume.Value;
                    _synthesizer.SpeakAsyncCancelAll();
                    _synthesizer.SetOutputToWaveFile(dialog.FileName);
                    _synthesizer.Speak(text);
                    _synthesizer.SetOutputToDefaultAudioDevice();

                    if (File.Exists(dialog.FileName))
                    {
                        statusLabel.Text = "Saved: " + Path.GetFileName(dialog.FileName);
                        MessageBox.Show("Audio file saved successfully.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    _synthesizer.SetOutputToDefaultAudioDevice();
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void trackRate_Scroll(object sender, EventArgs e)
        {
            labelRateValue.Text = trackRate.Value.ToString();
        }

        private void trackVolume_Scroll(object sender, EventArgs e)
        {
            labelVolumeValue.Text = trackVolume.Value.ToString();
        }

        private void Synthesizer_SpeakStarted(object sender, SpeakStartedEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => statusLabel.Text = "Speaking"));
                return;
            }

            statusLabel.Text = "Speaking";
        }

        private void Synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => statusLabel.Text = e.Cancelled ? "Stopped" : "Completed"));
                return;
            }

            statusLabel.Text = e.Cancelled ? "Stopped" : "Completed";
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _synthesizer.SpeakAsyncCancelAll();
            _synthesizer.Dispose();
            base.OnFormClosed(e);
        }
    }
}
